import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private final static String query= "insert into emp_mst (EMPCODE,EMPNAME,DEPARTMENT,EMP_EMAIL,DATEOFBIRTH,AGE,Status) values(?,?,?,?,?,?,?)";
    /**
     * Default constructor. 
     */
   
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter pw=response.getWriter();
				
		response.setContentType("text/html");
		
        //get string
	//	String ID=request.getParameter("ID");	
		String CODE=request.getParameter("EMPCODE");	
		String NAME=request.getParameter("username");
		String DEPARTMENT=request.getParameter("DEPRATMENT");
		String EMAIL=request.getParameter("Email");
		String dob=request.getParameter("txtbirthdate");
		String AGE=request.getParameter("txtage");
		String Status=request.getParameter("status");
		//load the jdbc drivers
	try
	{
		Class.forName("com.mysql.cj.jdbc.Driver");
		}

	catch(Exception e)
	{
		e.printStackTrace() ;
	}
	// generate connection
	try(Connection con=DriverManager.getConnection("jdbc:mysql:///mydb","root","gaurav");
	PreparedStatement ps=con.prepareStatement(query);)
	
	//set the values
	{
//      ps.setString(1, ID);
      ps.setString(1,CODE);
      ps.setString(2,NAME);
      ps.setString(3,DEPARTMENT );
      ps.setString(4,EMAIL);
      ps.setString(5,dob);
      ps.setString(6,"12" );
      ps.setString(7,Status);
      //execute query
      int count=ps.executeUpdate();
      if(count==1)
      {
    	 pw.println("<h2>record registered complete </h2>");
      }
      else {
     	 pw.println("<h2>record not registered complete </h2>");
       }
       
	}
      
    
	catch(SQLException se)	
	{  pw.println("<h2>" +se.getMessage()+ "</h2>");
		se.printStackTrace();
		}
	catch(Exception e) {
		e.printStackTrace();
	}
	pw.println("<a href='listt.html'> <button class='button button -outline-success'> REGISTER AGAIN</button></a>");
	
	pw.close();
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}