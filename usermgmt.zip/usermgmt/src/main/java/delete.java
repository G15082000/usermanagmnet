

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/deleteurl")
public class delete extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private final static String query= "delete from  emp_mst where ID = ?";
    /**
     * Default constructor. 
     */
   
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter pw=response.getWriter();
				
		response.setContentType("text/html");	
        //get string
	int ID=Integer.parseInt (request.getParameter("ID"));
		
		//load the jdbc drivers
	try
	{
		Class.forName("com.mysql.cj.jdbc.Driver");
		}

	catch(Exception e)
	{
		e.printStackTrace() ;
	}
	// generate connection
	try(Connection con=DriverManager.getConnection("jdbc:mysql:///mydb","root","gaurav");
	PreparedStatement ps=con.prepareStatement(query);)
	
	//set the values
	{
  ps.setInt(1, ID );
      //execute query
      int count=ps.executeUpdate();
      if(count==1)
      {
    	 pw.println("<h2>record delete complete </h2>");
      }
      else {
     	 pw.println("<h2>record not delete complete </h2>");
       }
       
	}
      
    
	catch(SQLException se)	
	{  pw.println("<h2>" +se.getMessage()+ "</h2>");
		se.printStackTrace();
		}
	catch(Exception e) {
		e.printStackTrace();
	}
    pw.println("<a href='listt.html'> <button class='button button -outline-success'>listt</button></a>");
    pw.println("<a href='Showuser'> <button class='button button -outline-success'>Show User</button></a>");
	pw.println("</div>");
	pw.close();
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}